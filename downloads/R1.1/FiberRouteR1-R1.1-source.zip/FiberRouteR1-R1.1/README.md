# 纤路 R1.1 修正版

基于2026-10-25交接源码制作，版本1.1.0。C#/.NET 8 Windows Forms + SQLite，Windows x64自包含便携程序。

修复CSV默认UTF-8导致非UTF-8文件无法预览的问题；支持严格自动编码识别、XLS/XLSX原生流式读取、工作表选择、字段映射和后台导入；重排四页界面并增加真实节点连线示意图。人工类型和资源回退规则保留。

当前验证：核心测试通过，Windows交叉构建通过。Linux无法运行Windows Forms，尚未完成Windows桌面实际交互或截图验收；请先用附带调测数据试用。未配置线上更新源。

## 开发

在当前检出目录开发，不需要Git worktree。

```bash
bash scripts/install.sh
. scripts/dotnet-env.sh
dotnet run --project tests/FiberRoute.Tests -c Release
bash scripts/package.sh
```

脚本以自身目录定位项目；SDK 8.0.426，下载时校验SHA512，依赖版本锁定。生成产物为 artifacts/FiberRouteR1-win-x64-R1.1.zip。测试输入为tests/fixtures真实二进制XLS及XLSX；tests/generate_fixtures.py仅为开发时重新生成夹具用，不随成品运行。

完整解压后运行“纤路R1.exe”，不需要用户安装.NET、Python或编译。使用说明和验证边界见docs目录。
