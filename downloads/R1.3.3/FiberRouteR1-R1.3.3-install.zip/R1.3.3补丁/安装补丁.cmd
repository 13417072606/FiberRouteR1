@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-R1.3.3-patch.ps1" -OfflineZip "%~dp0FiberRouteR1-R1.3.3-patch.zip" -NoOpen
if errorlevel 1 (
  echo.
  echo Installation failed. Please read the error above.
  pause
  exit /b 1
)
echo.
echo Done. Start the app using your existing shortcut.
pause
