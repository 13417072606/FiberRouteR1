using FiberRoute.Core;
using System.Text.Json;
namespace FiberRoute.App;
public sealed partial class MainForm
{
    readonly DataGridView clusterGrid=Grid(),assignmentGrid=Grid();
    readonly FlowLayoutPanel typePills=Flow();readonly NumericUpDown typePage=Num(1,99999,1);readonly Label typePageLabel=L("");
    readonly TextBox clusterSearch=new(){Width=280};readonly ComboBox stateFilter=new(){Width=115,DropDownStyle=ComboBoxStyle.DropDownList};
    List<TypeAssignment> assignments=[];List<ClusterRecord> pendingClusters=[];List<ClusterRecord> visibleClusters=[];
    readonly Panel previewPanel=new(){Dock=DockStyle.Bottom,Height=240,Visible=false};
    readonly TextBox editName=new(){ReadOnly=true,Width=260},editType=new(){Width=260};readonly Label editSource=L(""),editReason=L("");
    string RawStatus(int index){try{var r=JsonSerializer.Deserialize<Dictionary<string,string>>(store.Raw(index));return r?.GetValueOrDefault("业务状态","")??"";}catch{return "";}}
    void BuildTypes()
    {
        var tab=Tab("节点类型");var inner=new TabControl{Dock=DockStyle.Fill,Padding=new Point(18,8)};var nodeTab=new TabPage("节点类型"){Padding=new Padding(8),BackColor=Color.White};var groupTab=new TabPage("集群管理"){Padding=new Padding(8),BackColor=Color.White};inner.TabPages.Add(nodeTab);inner.TabPages.Add(groupTab);tab.Controls.Add(inner);
        stateFilter.Items.AddRange(["全部状态","待确认","已确认","需核对"]);stateFilter.SelectedIndex=0;
        var search=Flow();search.Controls.AddRange([typeSearch,stateFilter,B("筛选",()=>{typePage.Value=1;LoadTypes();}),B("列设置",()=>ShowColumns(typeGrid)),B("导入类型表",ImportTypeTables),B("导出节点类型",()=>{var p=Save("节点类型.csv");if(p!=null)Csv.Write(p,new[]{new object?[]{"节点名称","节点类型","确认状态","来源","原因"}}.Concat(store.Graph.Nodes.Select(n=>new object?[]{n.Name,n.Type,n.Confirmation,n.Source,n.Reason})));})]);
        var editor=Stack();editName.Multiline=true;editName.Height=90;editReason.MaximumSize=new Size(280,0);editSource.MaximumSize=new Size(280,0);
        editor.Controls.AddRange([L("编辑节点"),editName,L("节点类型（英文;分隔多标签）"),editType,editSource,editReason,B("保存修改并确认",async()=>{if(busy||editName.Text.Length==0)return;if(string.IsNullOrWhiteSpace(editType.Text))throw new InvalidDataException("类型不能为空");string name=editName.Text,type=string.Join(';',editType.Text.Split(';',StringSplitOptions.TrimEntries|StringSplitOptions.RemoveEmptyEntries).Select(Store.NormalizeType).Distinct());await Work("保存节点类型…",ct=>Task.Run(()=>store.ApplyTypeAssignments([new(name,type,"人工修改","已确认","")],ct),ct));RefreshData();})]);
        typeGrid.SelectionChanged+=(_,_)=>{if(typeGrid.CurrentRow?.Cells["名称"].Value is not string name)return;var n=store.Graph.Nodes.FirstOrDefault(n=>n.Name==name);if(n==null)return;editName.Text=n.Name;editType.Text=n.Type;editSource.Text="来源："+n.Source;editReason.Text="确认状态："+n.Confirmation+(n.Reason.Length>0?"\n"+n.Reason:"");};
        var list=new Panel{Dock=DockStyle.Fill};list.Controls.Add(typeGrid);var pager=Flow();pager.Dock=DockStyle.Bottom;pager.Controls.AddRange([B("上一页",()=>{if(typePage.Value>1)typePage.Value--;LoadTypes();}),typePage,B("跳转",LoadTypes),B("下一页",()=>{typePage.Value++;LoadTypes();}),typePageLabel]);list.Controls.Add(pager);
        nodeTab.Controls.Add(Columns(73,list,27,editor));nodeTab.Controls.Add(previewPanel);nodeTab.Controls.Add(search);nodeTab.Controls.Add(typePills);
        previewPanel.Controls.Add(assignmentGrid);var buttons=Flow();buttons.Controls.AddRange([B("确认应用类型表",async()=>{if(busy)return;var values=assignments.ToArray();bool ok=await Work("保存类型表与确认状态…",ct=>Task.Run(()=>store.ApplyTypeAssignments(values,ct),ct));if(ok){previewPanel.Visible=false;RefreshData();}}),B("取消预览",()=>{assignments=[];previewPanel.Visible=false;}),B("导出匹配报告",()=>{var p=Save("类型匹配报告.csv");if(p!=null)Csv.Write(p,new[]{new object?[]{"设施名称","类型","确认状态","原因","来源"}}.Concat(assignments.Select(x=>new object?[]{x.Name,x.Type,x.Status,x.Reason,x.Source})));})]);previewPanel.Controls.Add(buttons);
        var groupTop=Flow();groupTop.Controls.AddRange([clusterSearch,B("搜索",LoadClusters),B("导入集群表",ImportClusterTable),B("新建集群",()=>EditCluster(null)),B("修改集群",()=>{if(clusterGrid.CurrentRow?.Cells["序号"].Value is int i)EditCluster(visibleClusters[i-1]);}),B("删除集群",()=>{if(busy)return;if(clusterGrid.CurrentRow?.Cells["序号"].Value is int i&&MessageBox.Show("删除选中集群关系？原资源不删除。","确认",MessageBoxButtons.YesNo)==DialogResult.Yes){store.RemoveCluster(visibleClusters[i-1].Id);RefreshData();}}),B("导出集群",()=>{var p=Save("集群关系.csv");if(p!=null)Csv.Write(p,new[]{new object?[]{"设备名称","集群类型","集群列表","确认状态","原因","启用"}}.Concat(store.Clusters().Select(c=>new object?[]{c.Name,c.Type,string.Join(',',c.Members),c.Status,c.Reason,c.Enabled})));})]);groupTab.Controls.Add(clusterGrid);groupTab.Controls.Add(groupTop);
        var t=new System.Windows.Forms.Timer{Interval=300};typeSearch.TextChanged+=(_,_)=>{t.Stop();t.Start();};t.Tick+=(_,_)=>{t.Stop();typePage.Value=1;LoadTypes();};FormClosed+=(_,_)=>t.Dispose();stateFilter.SelectedIndexChanged+=(_,_)=>{typePage.Value=1;LoadTypes();};
    }
    Graph? pillGraph;string pillChoice="";
    void LoadTypes()
    {
        string chosen=nodeType.SelectedItem as string??"全部",state=stateFilter.Text;var rows=store.Graph.Nodes.Where(n=>n.Name.Contains(typeSearch.Text.Trim(),StringComparison.OrdinalIgnoreCase)&&(chosen=="全部"||n.Type.Split(';').Contains(chosen))&&(state=="全部状态"||state.Length==0||n.Confirmation==state)).ToArray();int pages=Math.Max(1,(rows.Length+99)/100);if(typePage.Value>pages)typePage.Value=pages;
        typeGrid.DataSource=rows.Skip(((int)typePage.Value-1)*100).Take(100).Select(n=>new{名称=n.Name,类型=n.Type,确认状态=n.Confirmation,来源=n.Source,原因=n.Reason}).ToList();typePageLabel.Text=$"共{rows.Length:N0}条 / {pages}页";
        if(ReferenceEquals(pillGraph,store.Graph)&&pillChoice==chosen)return;pillGraph=store.Graph;pillChoice=chosen;var totals=store.Graph.Nodes.SelectMany(n=>n.Type.Split(';').Distinct()).GroupBy(x=>x).ToDictionary(g=>g.Key,g=>g.Count());
        typePills.Controls.Clear();foreach(string type in new[]{"全部","光交箱","机房","分纤箱","站点","光终端盒","多媒体箱","未识别"}.Concat(store.Graph.Nodes.SelectMany(n=>n.Type.Split(';'))).Distinct())
        {int num=type=="全部"?store.Graph.Nodes.Length:totals.GetValueOrDefault(type);var b=B($"{type}  {num:N0}",()=>{nodeType.SelectedItem=type;typePage.Value=1;LoadTypes();});b.BackColor=chosen==type?accent:Color.FromArgb(241,247,248);b.ForeColor=chosen==type?Color.White:Color.FromArgb(35,65,70);typePills.Controls.Add(b);}
    }
    async Task ImportTypeTables()
    {
        if(busy)return;using var files=new OpenFileDialog{Filter=TableInput.Filter,Multiselect=true};if(files.ShowDialog()!=DialogResult.OK)return;var selected=new List<(string Path,string Type,string? Sheet)>();
        foreach(string file in files.FileNames)
        {
            using var d=new Form{Text="类型表字段/类别 · "+Path.GetFileName(file),Width=680,Height=340,Font=Font};var p=Stack();var type=new ComboBox{Width=250,DropDownStyle=ComboBoxStyle.DropDown};type.Items.AddRange(["（读取表内节点类型列）","光交箱","机房","分纤箱","光终端盒","多媒体箱","站点"]);type.Text=Path.GetFileName(file) switch{var n when n.Contains("ODF",StringComparison.OrdinalIgnoreCase)=>"机房",var n when n.Contains("光交")=>"光交箱",var n when n.Contains("分纤")=>"分纤箱",var n when n.Contains("终端盒")=>"光终端盒",var n when n.Contains("多媒体")=>"多媒体箱",_=>"（读取表内节点类型列）"};
            InputInfo? info=null;bool ok=await Work("识别类型文件…",async ct=>{info=await Task.Run(()=>TableInput.Inspect(file,"自动",ct),ct);});if(!ok)return;var sh=new ComboBox{Width=300,DropDownStyle=ComboBoxStyle.DropDownList};sh.Items.AddRange(info!.Sheets);if(sh.Items.Count>0)sh.SelectedIndex=0;p.Controls.AddRange([L("设施名称自动匹配；其他辅助字段的重复表头不影响匹配。"),L("本文件对应节点类型"),type,L("工作表（CSV无需选择）"),sh,B("继续生成预览",()=>d.DialogResult=DialogResult.OK)]);d.Controls.Add(p);if(d.ShowDialog(this)!=DialogResult.OK)return;selected.Add((file,type.Text.StartsWith('（')?"":type.Text,sh.SelectedItem as string));
        }
        bool done=await Work("读取类型表并匹配…",async ct=>{assignments=await Task.Run(()=>store.PreviewTypeFiles(selected,ct),ct);});if(done){var known=store.Graph.Nodes.Select(n=>n.Name).ToHashSet();assignmentGrid.DataSource=assignments.Take(1000).Select(x=>new{设施=x.Name,类型=x.Type,确认状态=x.Status,原因=x.Reason,当前资源匹配=known.Contains(x.Name)?"匹配":"待资源匹配"}).ToList();previewPanel.Visible=true;status.Text=$"类型预览 {assignments.Count:N0} 项（显示前1000），需核对 {assignments.Count(x=>x.Status=="需核对"):N0}；确认后保存。";}
    }
    void LoadClusters(){visibleClusters=store.Clusters().Where(c=>c.Name.Contains(clusterSearch.Text.Trim(),StringComparison.OrdinalIgnoreCase)||c.Members.Any(n=>n.Contains(clusterSearch.Text.Trim(),StringComparison.OrdinalIgnoreCase))).ToList();clusterGrid.DataSource=visibleClusters.Select((c,i)=>new{序号=i+1,集群名称=c.Name,成员数=c.Members.Length,类型=c.Type,确认状态=c.Status,路由启用=c.Enabled,原因=c.Reason,成员=string.Join("；",c.Members)}).ToList();}
    async Task ImportClusterTable()
    {
        if(busy)return;using var file=new OpenFileDialog{Filter=TableInput.Filter};if(file.ShowDialog()!=DialogResult.OK)return;string? sheet=null;InputInfo? info=null;if(!await Work("识别集群文件…",async ct=>{info=await Task.Run(()=>TableInput.Inspect(file.FileName,"自动",ct),ct);}))return;
        if(info!.Sheets.Length>1){using var d=new Form{Text="选择集群工作表",Width=440,Height=200,Font=Font};var list=new ComboBox{Dock=DockStyle.Top,DropDownStyle=ComboBoxStyle.DropDownList};list.Items.AddRange(info.Sheets);list.SelectedIndex=0;d.Controls.Add(list);var ok=B("确定",()=>d.DialogResult=DialogResult.OK);ok.Dock=DockStyle.Bottom;d.Controls.Add(ok);if(d.ShowDialog(this)!=DialogResult.OK)return;sheet=list.Text;}
        if(!await Work("分析集群成员与异常…",async ct=>{pendingClusters=await Task.Run(()=>store.PreviewClusters(file.FileName,sheet,ct),ct);}))return;
        var replaceMode=new CheckBox{Text="全量替换表格关系（保留人工维护）",Checked=true,AutoSize=true};
        using var preview=new Form{Text="集群导入预览 · 确认后保存",Width=1100,Height=650,Font=Font};var grid=Grid();grid.DataSource=pendingClusters.Select(c=>new{集群=c.Name,成员数=c.Members.Length,确认状态=c.Status,原因=c.Reason,启用=c.Enabled,成员=string.Join("；",c.Members)}).ToList();grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;preview.Controls.Add(grid);var controls=Flow();controls.Controls.AddRange([replaceMode,L($"归并后{pendingClusters.Count}项，需核对{pendingClusters.Count(c=>c.Status=="需核对")}项；异常关系不参与合并。"),B("确认导入",()=>preview.DialogResult=DialogResult.OK),B("取消",()=>preview.DialogResult=DialogResult.Cancel)]);preview.Controls.Add(controls);if(preview.ShowDialog(this)!=DialogResult.OK)return;
        if(await Work("保存集群关系…",ct=>Task.Run(()=>store.SaveClusters(pendingClusters,replaceMode.Checked,ct),ct)))RefreshData();
    }
    void EditCluster(ClusterRecord? old)
    {
        if(busy)return;using var d=new Form{Text=old==null?"新建集群":"修改集群",Width=700,Height=660,Font=Font};var p=Stack();var name=new TextBox{Text=old?.Name??""};var type=new TextBox{Text=old?.Type??"光交箱"};var members=new TextBox{Multiline=true,Height=230,ScrollBars=ScrollBars.Vertical,Text=string.Join(Environment.NewLine,old?.Members??[])};var enabled=new CheckBox{Text="启用该集群参与路由",Checked=old?.Enabled??true,Height=32};p.Controls.AddRange([L("集群名称"),name,L("类型"),type,L("成员完整名称，每行一个；仅维护有明确连通关系的设备"),members,enabled,B("人工确认并保存",async()=>{
            string[] ns=members.Lines.Select(x=>x.Trim()).Where(x=>x.Length>0).Distinct().Order(StringComparer.Ordinal).ToArray();if(string.IsNullOrWhiteSpace(name.Text)||ns.Length<2)throw new InvalidDataException("请输入集群名称及至少两个成员");string id=old?.Id??Guid.NewGuid().ToString("N");var c=new ClusterRecord(id,name.Text.Trim(),Store.NormalizeType(type.Text),ns,"人工修改","已确认","",enabled.Checked);if(await Work("保存集群…",ct=>Task.Run(()=>store.SaveClusters([c],ct:ct),ct))){d.DialogResult=DialogResult.OK;RefreshData();}})]);d.Controls.Add(p);d.ShowDialog(this);
    }
}
