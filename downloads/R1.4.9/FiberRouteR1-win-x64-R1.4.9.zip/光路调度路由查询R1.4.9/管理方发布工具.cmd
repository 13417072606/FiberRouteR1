@echo off
chcp 65001 >nul
if "%~1"=="" (
  start "" "%~dp0管理方发布工具.exe"
) else (
  "%~dp0程序\FiberRoute.Admin.exe" %*
)
