@echo off
chcp 65001 >nul
"%~dp0程序\FiberRoute.Admin.exe" %*
if "%~1"=="" pause
