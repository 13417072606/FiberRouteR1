@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Install-R1.5.0-patch.ps1" -OfflineZip "%~dp0FiberRouteR1-R1.5.0-patch.zip" -NoOpen
if errorlevel 1 (
  echo Installation failed. Please read the error above.
  pause
  exit /b 1
)
echo SUCCESS. Start the app with your existing shortcut.
pause
